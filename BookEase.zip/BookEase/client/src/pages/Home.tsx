import { Hero } from "@/components/Hero";
import { ServiceAccordion } from "@/components/ServiceAccordion";
import { Footer } from "@/components/Footer";
import { WhatsAppButton } from "@/components/WhatsAppButton";
import { Header } from "@/components/Header";

export default function Home() {
  return (
    <div className="min-h-screen">
      <Header />
      <Hero />
      <ServiceAccordion />
      <Footer />
      <WhatsAppButton />
    </div>
  );
}
