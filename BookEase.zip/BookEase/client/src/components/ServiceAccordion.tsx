import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Badge } from "@/components/ui/badge";

type Service = {
  id: string;
  name: string;
  description: string;
  badge?: string;
};

type ServiceCategory = {
  id: string;
  title: string;
  icon: string;
  color: "primary" | "chart-2" | "chart-3" | "chart-4";
  services: Service[];
};

const serviceCategories: ServiceCategory[] = [
  {
    id: "therapeutic",
    title: "Masajes Terapéuticos",
    icon: "💆‍♀️",
    color: "primary",
    services: [
      {
        id: "decontracting",
        name: "Masajes Descontracturantes",
        description: "Diferentes técnicas personalizadas para aliviar tensiones musculares y contracturas. Ideal para dolores de espalda, cuello y hombros.",
        badge: "El más solicitado",
      },
      {
        id: "migraine",
        name: "Masajes para Migrañas",
        description: "Tratamiento especializado para reducir y prevenir dolores de cabeza mediante técnicas de presión y relajación.",
        badge: "Alivio inmediato",
      },
      {
        id: "shiatsu",
        name: "Shiatsu",
        description: "Digitopresión japonesa para equilibrar la energía del cuerpo y promover el bienestar integral.",
      },
      {
        id: "biomagnetism",
        name: "Biomagnetismo",
        description: "Restaura el balance del pH corporal para una salud integral mediante la aplicación de imanes.",
      },
    ],
  },
  {
    id: "specialized",
    title: "Masajes Especializados",
    icon: "🤰",
    color: "chart-2",
    services: [
      {
        id: "pregnancy",
        name: "Masaje para Embarazadas",
        description: "Cuidado especial durante la gestación para aliviar el peso, la hinchazón y promover la relajación profunda.",
      },
      {
        id: "postpartum",
        name: "Masaje Post-Parto",
        description: "Ayuda a la recuperación física y emocional después del nacimiento de tu bebé.",
        badge: "Recuperación esencial",
      },
    ],
  },
  {
    id: "contouring",
    title: "Tratamientos Reductores",
    icon: "🔥",
    color: "chart-3",
    services: [
      {
        id: "ultracavitation",
        name: "Ultracavitador",
        description: "Tecnología avanzada para reducción de medidas y eliminación de grasa localizada mediante ondas ultrasónicas.",
        badge: "Resultados visibles",
      },
      {
        id: "electrostimulation",
        name: "Electroestimulación",
        description: "Tonificación muscular intensa sin esfuerzo. Fortalece y define tus músculos.",
      },
      {
        id: "heat-belt",
        name: "Faja Reductora con Calor y Vibración",
        description: "Tratamiento complementario que potencia la quema de grasas y reafirma la piel.",
      },
    ],
  },
  {
    id: "circulatory",
    title: "Tratamientos Circulatorios",
    icon: "🌊",
    color: "chart-4",
    services: [
      {
        id: "lymphatic",
        name: "Drenaje Linfático Cuerpo Entero",
        description: "El tratamiento estrella para eliminar toxinas, reducir la celulitis y deshinchazón. Mejora la circulación y promueve la regeneración celular.",
        badge: "Detox total",
      },
      {
        id: "lymphatic-legs",
        name: "Drenaje Linfático Piernas",
        description: "Tratamiento focalizado para aliviar piernas cansadas, reducir hinchazón y mejorar la circulación.",
      },
      {
        id: "cold-wraps",
        name: "Vendas Frías",
        description: "Terapia refrescante para pies y piernas que alivia el cansancio, reduce la inflamación y mejora la circulación.",
      },
      {
        id: "circulatory-massage",
        name: "Masajes Circulatorios Piernas",
        description: "Masaje especializado para mejorar el retorno venoso y aliviar la pesadez de piernas.",
      },
    ],
  },
];

export function ServiceAccordion() {
  return (
    <section className="py-12 md:py-20 px-4" id="servicios">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="font-serif text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-4">
            Nuestros Servicios
          </h2>
          <p className="text-muted-foreground text-lg md:text-xl max-w-2xl mx-auto">
            Descubre la transformación que tu cuerpo necesita con nuestra masajista Carolina Arias
          </p>
        </div>

        <div className="space-y-8">
          {serviceCategories.map((category) => (
            <div key={category.id} className="space-y-4">
              <div className="flex items-center gap-3 pb-3 border-b-2" style={{
                borderColor: `hsl(var(--${category.color}))`,
              }}>
                <span className="text-2xl md:text-3xl">{category.icon}</span>
                <h3 className="font-bold text-2xl md:text-3xl" style={{
                  color: `hsl(var(--${category.color}))`,
                }}>
                  {category.title}
                </h3>
              </div>

              <Accordion type="single" collapsible className="space-y-3">
                {category.services.map((service) => (
                  <AccordionItem
                    key={service.id}
                    value={service.id}
                    className="border rounded-xl shadow-lg hover:shadow-xl transition-shadow overflow-hidden"
                    data-testid={`accordion-service-${service.id}`}
                  >
                    <AccordionTrigger
                      className="px-5 py-4 hover:no-underline hover-elevate"
                      style={{
                        backgroundColor: `hsl(var(--${category.color}) / 0.05)`,
                      }}
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center gap-2 text-left flex-1">
                        <span
                          className="text-lg md:text-xl font-bold"
                          style={{ color: `hsl(var(--${category.color}))` }}
                        >
                          {service.name}
                        </span>
                        {service.badge && (
                          <Badge
                            variant="secondary"
                            className="text-xs w-fit"
                            data-testid={`badge-${service.id}`}
                          >
                            {service.badge}
                          </Badge>
                        )}
                      </div>
                    </AccordionTrigger>
                    <AccordionContent
                      className="px-5 py-4 border-l-4"
                      style={{
                        backgroundColor: `hsl(var(--${category.color}) / 0.08)`,
                        borderColor: `hsl(var(--${category.color}))`,
                      }}
                    >
                      <p className="text-muted-foreground leading-relaxed">
                        {service.description}
                      </p>
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
