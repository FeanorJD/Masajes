import { Button } from "@/components/ui/button";
import { Phone, MessageCircle } from "lucide-react";
import heroImage from "@assets/generated_images/Serene_spa_massage_room_5f43978f.png";

export function Hero() {
  const handleWhatsApp = () => {
    window.open("https://wa.me/5492657693661", "_blank");
  };

  const handlePhone = () => {
    window.location.href = "tel:2657693661";
  };

  return (
    <section className="relative h-[70vh] min-h-[500px] w-full overflow-hidden">
      <div 
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: `url(${heroImage})`,
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-black/40 to-black/60" />
      </div>

      <div className="relative h-full flex flex-col items-center justify-center px-4 text-center z-10">
        <div className="max-w-4xl">
          <div className="mb-6">
            <p className="text-white/90 text-lg md:text-xl font-medium mb-2">
              Yanina Velazquez
            </p>
            <div className="w-20 h-0.5 bg-white/60 mx-auto mb-4" />
            <p className="text-white/80 text-sm md:text-base uppercase tracking-wider">
              Salud y Belleza
            </p>
          </div>

          <h1 className="font-serif text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold text-white mb-6 leading-tight">
            Tu Santuario de Bienestar y Transformación
          </h1>

          <p className="text-white/90 text-lg md:text-xl lg:text-2xl font-medium mb-8 max-w-3xl mx-auto">
            Masajes terapéuticos, tratamientos especializados y cuidado integral para tu cuerpo
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button
              size="lg"
              onClick={handleWhatsApp}
              data-testid="button-whatsapp-hero"
              className="bg-primary text-primary-foreground border border-primary-border text-base md:text-lg px-8 hover-elevate active-elevate-2"
            >
              <MessageCircle className="mr-2 h-5 w-5" />
              Reservar por WhatsApp
            </Button>
            <Button
              variant="outline"
              size="lg"
              onClick={handlePhone}
              data-testid="button-phone-hero"
              className="bg-background/20 backdrop-blur-sm border-white/30 text-white hover:bg-background/30 text-base md:text-lg px-8"
            >
              <Phone className="mr-2 h-5 w-5" />
              2657693661
            </Button>
          </div>

          <p className="text-white/70 text-sm mt-6">
            Respuesta en 24 horas
          </p>
        </div>
      </div>
    </section>
  );
}
