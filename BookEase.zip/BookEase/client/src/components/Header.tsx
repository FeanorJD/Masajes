import { ThemeToggle } from "./ThemeToggle";
import { Button } from "@/components/ui/button";
import { Menu } from "lucide-react";
import { useState } from "react";

export function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
      setMobileMenuOpen(false);
    }
  };

  return (
    <header className="sticky top-0 z-40 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <h1 className="font-serif text-xl md:text-2xl font-bold">
            Yanina Velazquez
          </h1>
          <span className="hidden sm:inline text-muted-foreground">|</span>
          <span className="hidden sm:inline text-sm text-muted-foreground">
            Salud y Belleza
          </span>
        </div>

        <nav className="hidden md:flex items-center gap-6">
          <button
            onClick={() => scrollToSection("servicios")}
            className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
            data-testid="link-services"
          >
            Servicios
          </button>
          <button
            onClick={() => scrollToSection("reservar")}
            className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
            data-testid="link-booking"
          >
            Reservar
          </button>
          <ThemeToggle />
        </nav>

        <div className="flex md:hidden items-center gap-2">
          <ThemeToggle />
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            data-testid="button-mobile-menu"
            className="hover-elevate active-elevate-2"
          >
            <Menu className="h-5 w-5" />
          </Button>
        </div>
      </div>

      {mobileMenuOpen && (
        <div className="md:hidden border-t bg-background">
          <nav className="flex flex-col gap-4 p-4">
            <button
              onClick={() => scrollToSection("servicios")}
              className="text-left font-medium hover:text-primary transition-colors"
              data-testid="link-services-mobile"
            >
              Servicios
            </button>
            <button
              onClick={() => scrollToSection("reservar")}
              className="text-left font-medium hover:text-primary transition-colors"
              data-testid="link-booking-mobile"
            >
              Reservar
            </button>
          </nav>
        </div>
      )}
    </header>
  );
}
