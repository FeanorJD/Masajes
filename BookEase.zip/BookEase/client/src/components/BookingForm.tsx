import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { MessageCircle, Phone, MapPin, Clock } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const services = [
  "Masajes Descontracturantes",
  "Masajes para Migrañas",
  "Shiatsu",
  "Biomagnetismo",
  "Masaje para Embarazadas",
  "Masaje Post-Parto",
  "Ultracavitador",
  "Electroestimulación",
  "Faja Reductora",
  "Drenaje Linfático Cuerpo Entero",
  "Drenaje Linfático Piernas",
  "Vendas Frías",
  "Masajes Circulatorios Piernas",
];

export function BookingForm() {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    email: "",
    service: "",
    date: "",
    time: "",
    message: "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const message = `Hola! Me gustaría reservar un turno:
Nombre: ${formData.name}
Servicio: ${formData.service}
Fecha preferida: ${formData.date}
Hora preferida: ${formData.time}
${formData.message ? `Mensaje: ${formData.message}` : ''}`;
    
    const whatsappUrl = `https://wa.me/5492657693661?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, "_blank");
    
    toast({
      title: "Redirigiendo a WhatsApp",
      description: "Te conectaremos para confirmar tu reserva.",
    });
  };

  const handleWhatsAppDirect = () => {
    window.open("https://wa.me/5492657693661", "_blank");
  };

  return (
    <section className="py-12 md:py-20 px-4 bg-secondary/30" id="reservar">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="font-serif text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-4">
            Reserva tu Sesión
          </h2>
          <p className="text-muted-foreground text-lg md:text-xl">
            Completa el formulario o contáctanos directamente
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          <Card className="shadow-xl">
            <CardHeader>
              <CardTitle className="text-2xl">Solicitar Turno</CardTitle>
              <CardDescription>
                Completa tus datos y te contactaremos para confirmar
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="name">Nombre completo *</Label>
                  <Input
                    id="name"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Tu nombre"
                    data-testid="input-name"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="phone">Teléfono *</Label>
                  <Input
                    id="phone"
                    type="tel"
                    required
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    placeholder="2657693661"
                    data-testid="input-phone"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="tu@email.com"
                    data-testid="input-email"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="service">Servicio *</Label>
                  <Select
                    required
                    value={formData.service}
                    onValueChange={(value) => setFormData({ ...formData, service: value })}
                  >
                    <SelectTrigger id="service" data-testid="select-service">
                      <SelectValue placeholder="Selecciona un servicio" />
                    </SelectTrigger>
                    <SelectContent>
                      {services.map((service) => (
                        <SelectItem key={service} value={service}>
                          {service}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="date">Fecha preferida</Label>
                    <Input
                      id="date"
                      type="date"
                      value={formData.date}
                      onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                      data-testid="input-date"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="time">Hora preferida</Label>
                    <Input
                      id="time"
                      type="time"
                      value={formData.time}
                      onChange={(e) => setFormData({ ...formData, time: e.target.value })}
                      data-testid="input-time"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="message">Mensaje adicional</Label>
                  <Textarea
                    id="message"
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    placeholder="Alguna consulta o comentario..."
                    rows={3}
                    data-testid="textarea-message"
                  />
                </div>

                <Button
                  type="submit"
                  className="w-full"
                  size="lg"
                  data-testid="button-submit-booking"
                >
                  <MessageCircle className="mr-2 h-5 w-5" />
                  Enviar por WhatsApp
                </Button>
              </form>
            </CardContent>
          </Card>

          <div className="space-y-6">
            <Card className="shadow-xl hover-elevate">
              <CardHeader>
                <CardTitle className="text-2xl">Contacto Directo</CardTitle>
                <CardDescription>
                  Prefiere hablar directamente? Escríbenos o llámanos
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button
                  onClick={handleWhatsAppDirect}
                  variant="default"
                  className="w-full"
                  size="lg"
                  data-testid="button-whatsapp-direct"
                >
                  <MessageCircle className="mr-2 h-5 w-5" />
                  WhatsApp: 2657693661
                </Button>

                <Button
                  onClick={() => window.location.href = "tel:2657693661"}
                  variant="outline"
                  className="w-full"
                  size="lg"
                  data-testid="button-phone-direct"
                >
                  <Phone className="mr-2 h-5 w-5" />
                  Llamar: 2657693661
                </Button>
              </CardContent>
            </Card>

            <Card className="shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="h-5 w-5" />
                  Horarios de Atención
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 text-muted-foreground">
                <p>Lunes a Viernes: 9:00 - 20:00</p>
                <p>Sábados: 9:00 - 14:00</p>
                <p className="text-sm mt-4 pt-4 border-t">
                  Respuesta en 24 horas o menos
                </p>
              </CardContent>
            </Card>

            <Card className="shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MapPin className="h-5 w-5" />
                  Ubicación
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  San Luis, Argentina
                </p>
                <p className="text-sm text-muted-foreground mt-2">
                  Dirección exacta proporcionada al confirmar tu turno
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}
