import { MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

export function WhatsAppButton() {
  const handleClick = () => {
    window.open("https://wa.me/5492657693661", "_blank");
  };

  return (
    <Button
      onClick={handleClick}
      size="lg"
      className="fixed bottom-6 right-6 h-14 w-14 md:h-16 md:w-16 rounded-full shadow-2xl z-50 bg-[#25D366] hover:bg-[#20bd5a] border-0 text-white p-0"
      data-testid="button-whatsapp-float"
    >
      <MessageCircle className="h-7 w-7 md:h-8 md:w-8" />
      <span className="sr-only">Contactar por WhatsApp</span>
    </Button>
  );
}
