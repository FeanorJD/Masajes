import { ServiceAccordion } from "../ServiceAccordion";

export default function ServiceAccordionExample() {
  return <ServiceAccordion />;
}
