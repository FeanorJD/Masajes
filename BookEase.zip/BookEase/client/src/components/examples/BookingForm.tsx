import { BookingForm } from "../BookingForm";

export default function BookingFormExample() {
  return <BookingForm />;
}
