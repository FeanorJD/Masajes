import { MessageCircle, Phone, Instagram, Facebook } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-card border-t border-card-border">
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid md:grid-cols-3 gap-8">
          <div>
            <h3 className="font-serif text-2xl font-bold mb-4">
              Yanina Velazquez
            </h3>
            <p className="text-muted-foreground mb-4">
              Salud y Belleza
            </p>
            <p className="text-sm text-muted-foreground">
              Tu santuario de bienestar y transformación. Profesional certificada en masajes terapéuticos y tratamientos estéticos.
            </p>
          </div>

          <div>
            <h4 className="font-semibold text-lg mb-4">Servicios</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>Masajes Terapéuticos</li>
              <li>Masajes Especializados</li>
              <li>Tratamientos Reductores</li>
              <li>Tratamientos Circulatorios</li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold text-lg mb-4">Contacto</h4>
            <div className="space-y-3">
              <a
                href="https://wa.me/5492657693661"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors hover-elevate"
                data-testid="link-whatsapp-footer"
              >
                <MessageCircle className="h-4 w-4" />
                2657693661
              </a>
              <a
                href="tel:2657693661"
                className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors hover-elevate"
                data-testid="link-phone-footer"
              >
                <Phone className="h-4 w-4" />
                Llamar
              </a>
              <div className="flex gap-4 pt-2">
                <a
                  href="#"
                  className="text-muted-foreground hover:text-foreground transition-colors hover-elevate"
                  data-testid="link-instagram"
                  onClick={(e) => {
                    e.preventDefault();
                    console.log("Instagram link clicked");
                  }}
                >
                  <Instagram className="h-5 w-5" />
                </a>
                <a
                  href="#"
                  className="text-muted-foreground hover:text-foreground transition-colors hover-elevate"
                  data-testid="link-facebook"
                  onClick={(e) => {
                    e.preventDefault();
                    console.log("Facebook link clicked");
                  }}
                >
                  <Facebook className="h-5 w-5" />
                </a>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-card-border mt-8 pt-8 text-center text-sm text-muted-foreground">
          <p>&copy; 2025 Yanina Velazquez - Salud y Belleza. Todos los derechos reservados.</p>
        </div>
      </div>
    </footer>
  );
}
